/* admin.js — link it 어드민 공통 JavaScript */

(function () {
  "use strict";

  /* ── Active nav highlight ── */
  function setActiveNav() {
    var current = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll("[data-page]").forEach(function (el) {
      if (el.dataset.page === current) {
        el.classList.add("is-active");
      }
    });
  }

  /* ── Sidebar component (render + mobile toggle) ── */
  function initSidebar() {
    var sidebar = document.getElementById("adminSidebar");
    if (!sidebar) return;

    /* ── 1. Render canonical nav HTML ── */
    var page = location.pathname.split("/").pop() || "index.html";

    /* sub-page → parent main-link href */
    var SUB_TO_MAIN = {
      "product-create.html": "product-list.html",
      "category.html":       "product-list.html",
      "product-list.html":   "product-list.html",
      "order-list.html":     "order-list.html",
      "design.html":         "design.html",
      "seller-list.html":    "seller-list.html",
    };
    var activeMain = SUB_TO_MAIN[page] || page;

    function mc(href) {
      return "admin-sidebar__main" + (href === activeMain ? " is-active" : "");
    }
    function sc(href) {
      return "admin-sidebar__sub" + (href === page ? " is-active" : "");
    }
    function icon(src) {
      return '<img class="admin-sidebar__nav-icon" src="assets/SideNav/' + src + '" width="20" height="20" alt="" />';
    }

    sidebar.innerHTML =
      '<div class="admin-sidebar__logo">' +
        '<a href="index.html" class="admin-sidebar__logo-link">link it</a>' +
      '</div>' +
      '<nav class="admin-sidebar__nav">' +

        '<div class="admin-sidebar__group">' +
          '<a href="index.html" class="' + mc("index.html") + '">' +
            icon("icon-1.svg") +
            '<span>대시보드</span>' +
          '</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="product-list.html" class="' + mc("product-list.html") + '">' +
            icon("icon-2.svg") +
            '<span>상품관리</span>' +
          '</a>' +
          '<a href="product-create.html" class="' + sc("product-create.html") + '">상품 등록</a>' +
          '<a href="category.html" class="' + sc("category.html") + '">카테고리 관리</a>' +
          '<a href="product-list.html" class="' + sc("product-list.html") + '">상품목록</a>' +
          '<a href="#" class="admin-sidebar__sub">상품진열</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="order-list.html" class="' + mc("order-list.html") + '">' +
            icon("icon.svg") +
            '<span>주문관리</span>' +
          '</a>' +
          '<a href="order-list.html" class="' + sc("order-list.html") + '">주문내역</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="design.html" class="' + mc("design.html") + '">' +
            icon("icon-3.svg") +
            '<span>디자인</span>' +
          '</a>' +
          '<a href="design.html" class="' + sc("design.html") + '">디자인 관리</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="seller-list.html" class="' + mc("seller-list.html") + '">' +
            icon("icon-4.svg") +
            '<span>셀러 관리</span>' +
          '</a>' +
          '<a href="seller-list.html" class="' + sc("seller-list.html") + '">셀러 목록</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="notice.html" class="' + mc("notice.html") + '">' +
            icon("icon-5.svg") +
            '<span>공지사항</span>' +
          '</a>' +
        '</div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="settings.html" class="' + mc("settings.html") + '">' +
            icon("icon-6.svg") +
            '<span>환경설정</span>' +
          '</a>' +
        '</div>' +

        '<div class="admin-sidebar__divider"></div>' +

        '<div class="admin-sidebar__group">' +
          '<a href="../login.html" class="admin-sidebar__main admin-sidebar__main--logout">' +
            icon("icon-7.svg") +
            '<span>로그아웃</span>' +
          '</a>' +
        '</div>' +

      '</nav>';

    /* ── 2. Mobile hamburger toggle ── */
    var hamburger = document.getElementById("adminHamburger");
    var overlay = document.getElementById("adminOverlay");
    if (!hamburger) return;

    function openSidebar() {
      sidebar.classList.add("is-open");
      if (overlay) overlay.classList.add("is-visible");
    }
    function closeSidebar() {
      sidebar.classList.remove("is-open");
      if (overlay) overlay.classList.remove("is-visible");
    }

    hamburger.addEventListener("click", function (e) {
      e.stopPropagation();
      sidebar.classList.contains("is-open") ? closeSidebar() : openSidebar();
    });

    if (overlay) {
      overlay.addEventListener("click", closeSidebar);
    }
  }

  /* ── Product save btn ── */
  function initProductSave() {
    var btn = document.querySelector("#productSaveBtn");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      var form = document.querySelector("#productForm");
      if (!form) return;
      var nameField = form.querySelector("[name='productName']");
      if (nameField && !nameField.value.trim()) {
        alert("상품명을 입력해주세요.");
        nameField.focus();
        return;
      }
      var priceField = form.querySelector("[name='productPrice']");
      if (priceField && !priceField.value.trim()) {
        alert("판매가를 입력해주세요.");
        priceField.focus();
        return;
      }
      /* form.submit(); */
      alert("저장되었습니다.");
      location.href = "product-list.html";
    });
  }

  /* ── Category save btn ── */
  function initCategorySave() {
    var btn = document.querySelector("#categorySaveBtn");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      var nameField = document.querySelector("#categoryName");
      if (nameField && !nameField.value.trim()) {
        alert("카테고리명을 입력해주세요.");
        nameField.focus();
        return;
      }
      /* form.submit(); */
      alert("카테고리가 추가되었습니다.");
      if (nameField) nameField.value = "";
    });
  }

  /* ── Settings save btn ── */
  function initSettingsSave() {
    var btn = document.querySelector("#settingsSaveBtn");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      /* form.submit(); */
      alert("설정이 저장되었습니다.");
    });
  }

  /* ── Design save btn ── */
  function initDesignSave() {
    var btn = document.querySelector("#designSaveBtn");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      /* form.submit(); */
      alert("디자인 설정이 저장되었습니다.");
    });
  }

  /* ── Notice write btn ── */
  function initNoticeWrite() {
    var btn = document.querySelector("#noticeWriteBtn");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      /* navigate or open modal */
      alert("공지사항 작성 페이지로 이동합니다.");
    });
  }

  /* ── Search / filter btn ── */
  function initSearchBtns() {
    document.querySelectorAll("[data-action='search']").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        /* form.submit() or fetch filtering */
      });
    });
  }

  /* ── Product create: 탭 전환 / 옵션 행 추가·삭제 / 에디터 / 이미지 업로드 ── */
  function initProductCreate() {

    /* 1. 상세 페이지 설정 탭 전환 */
    var tabBtns = document.querySelectorAll(".product-tab-btn");
    var panels  = document.querySelectorAll(".product-detail-panel");
    if (tabBtns.length) {
      tabBtns.forEach(function (btn) {
        btn.addEventListener("click", function () {
          tabBtns.forEach(function (b) {
            b.classList.remove("is-active");
            b.setAttribute("aria-selected", "false");
          });
          btn.classList.add("is-active");
          btn.setAttribute("aria-selected", "true");

          var target = "panel-" + btn.dataset.tab;
          panels.forEach(function (panel) {
            panel.classList.toggle("is-active", panel.id === target);
          });
        });
      });
    }

    /* 2. 옵션 항목 추가 (+) */
    var TRASH_SVG = [
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"',
        ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">',
        '<polyline points="3 6 5 6 21 6"/>',
        '<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
      "</svg>"
    ].join("");

    var optAddRowBtn = document.getElementById("optAddRowBtn");
    var optionBody   = document.getElementById("optionInputBody");
    if (optAddRowBtn && optionBody) {
      optAddRowBtn.addEventListener("click", function () {
        var tr = document.createElement("tr");
        tr.innerHTML =
          '<td><input type="text" name="optName[]" placeholder="옵션명" /></td>' +
          '<td><input type="text" name="optValue[]" placeholder="값을 쉼표로 구분" /></td>' +
          '<td><input type="text" name="optCost[]" placeholder="추가 비용 (쉼표 구분)" /></td>' +
          '<td class="product-option-del-cell">' +
            '<button type="button" class="product-opt-del-row" aria-label="옵션 삭제">' +
              TRASH_SVG +
            '</button>' +
          '</td>';
        optionBody.appendChild(tr);
        tr.querySelector("input").focus();
      });
    }

    /* 3. 옵션 행 삭제 (이벤트 위임 — 초기 행 + 동적 행 모두 처리) */
    if (optionBody) {
      optionBody.addEventListener("click", function (e) {
        var delBtn = e.target.closest(".product-opt-del-row");
        if (!delBtn) return;
        var rows = optionBody.querySelectorAll("tr");
        if (rows.length <= 1) return; /* 마지막 행은 삭제 불가 */
        delBtn.closest("tr").remove();
      });
    }

    /* 4. 옵션 저장 → 조합 테이블 자동 생성 */
    var optSaveBtn  = document.getElementById("optSaveBtn");
    var optComboBody = document.getElementById("optComboBody");
    var comboTitle  = document.querySelector(".product-option-combo-title");
    if (optSaveBtn && optComboBody) {
      optSaveBtn.addEventListener("click", function () {
        /* 각 행에서 옵션값 수집 */
        var rows = optionBody ? optionBody.querySelectorAll("tr") : [];
        var groups = [];
        rows.forEach(function (row) {
          var valInput  = row.querySelector("[name='optValue[]']");
          var costInput = row.querySelector("[name='optCost[]']");
          var vals  = valInput  ? valInput.value.split(",").map(function (v) { return v.trim(); }).filter(Boolean) : [];
          var costs = costInput ? costInput.value.split(",").map(function (v) { return v.trim(); }) : [];
          if (vals.length) groups.push({ vals: vals, costs: costs });
        });

        if (!groups.length) {
          alert("옵션값을 입력한 뒤 저장하세요.");
          return;
        }

        /* Cartesian product */
        var combos = groups.reduce(function (acc, group) {
          var next = [];
          acc.forEach(function (prefix) {
            group.vals.forEach(function (val, i) {
              next.push({
                label: prefix.label ? prefix.label + " / " + val : val,
                cost:  group.costs[i] !== undefined ? group.costs[i] : ""
              });
            });
          });
          return next;
        }, [{ label: "", cost: "" }]);

        /* 조합 테이블 갱신 */
        optComboBody.innerHTML = "";
        combos.forEach(function (combo) {
          var tr = document.createElement("tr");
          tr.innerHTML =
            '<td style="text-align:center;"><input type="checkbox" name="optUse[]" checked style="accent-color:var(--admin-red);cursor:pointer;" /></td>' +
            '<td>' + combo.label + '</td>' +
            '<td><input type="number" class="product-tbl-input" name="optStock[]" value="0" min="0" /></td>' +
            '<td><input type="number" class="product-tbl-input" name="optAddCost[]" value="' + (combo.cost || 0) + '" min="0" /></td>';
          optComboBody.appendChild(tr);
        });

        if (comboTitle) {
          comboTitle.textContent = "옵션 조합 (" + combos.length + "개)";
        }

        /* 조합 섹션으로 스크롤 */
        optComboBody.closest(".admin-table-wrap").scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }

    /* 5. 옵션 조합 사용여부 전체 선택/해제 */
    var allUse = document.getElementById("optAllUse");
    if (allUse) {
      allUse.addEventListener("change", function () {
        document.querySelectorAll("[name='optUse[]']").forEach(function (cb) {
          cb.checked = allUse.checked;
        });
      });
    }

    /* 6. WYSIWYG 에디터 툴바 */
    document.querySelectorAll(".product-editor-toolbar-btn[data-cmd]").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        var cmd = btn.dataset.cmd;
        if (cmd === "createLink") {
          var url = prompt("링크 URL을 입력하세요:");
          if (url) document.execCommand(cmd, false, url);
        } else if (cmd === "insertImage") {
          var src = prompt("이미지 URL을 입력하세요:");
          if (src) document.execCommand(cmd, false, src);
        } else {
          document.execCommand(cmd, false, null);
        }
        var editor = document.getElementById("editorContent");
        if (editor) editor.focus();
        /* active 상태 토글 반영 */
        btn.classList.toggle("is-active", document.queryCommandState(cmd));
      });
    });

    /* 7. 상세 이미지 파일 업로드 미리보기 */
    var detailInput   = document.getElementById("detailImgInput");
    var previewGrid   = document.getElementById("detailPreviewGrid");
    if (detailInput && previewGrid) {
      detailInput.addEventListener("change", function (e) {
        Array.prototype.forEach.call(e.target.files, function (file) {
          if (!file.type.startsWith("image/")) return;
          var reader = new FileReader();
          reader.onload = function (ev) {
            var item = document.createElement("div");
            item.className = "product-detail-preview-item";
            item.innerHTML =
              '<img src="' + ev.target.result + '" alt="미리보기" />' +
              '<button type="button" class="product-detail-preview-del" aria-label="이미지 삭제">' +
                '&times;' +
              '</button>';
            previewGrid.appendChild(item);
          };
          reader.readAsDataURL(file);
        });
        e.target.value = "";
      });

      previewGrid.addEventListener("click", function (e) {
        if (e.target.classList.contains("product-detail-preview-del")) {
          e.target.parentElement.remove();
        }
      });
    }

    /* 8. 대표이미지 슬롯 클릭 → 파일 업로드 */
    var productImgInput = document.getElementById("productImgInput");
    var imgSlots = document.querySelectorAll(".product-img-slot");
    var currentSlot = null;
    if (productImgInput && imgSlots.length) {
      imgSlots.forEach(function (slot) {
        slot.addEventListener("click", function () {
          currentSlot = slot;
          productImgInput.value = "";
          productImgInput.click();
        });
        slot.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            currentSlot = slot;
            productImgInput.value = "";
            productImgInput.click();
          }
        });
      });

      productImgInput.addEventListener("change", function (e) {
        var file = e.target.files[0];
        if (!file || !currentSlot) return;
        var reader = new FileReader();
        reader.onload = function (ev) {
          currentSlot.innerHTML = '<img src="' + ev.target.result + '" alt="상품 이미지" />';
          currentSlot.classList.add("has-image");
        };
        reader.readAsDataURL(file);
      });
    }
  }

  /* ── Category page ── */
  function initCategoryPage() {
    var categoryList = document.getElementById("categoryList");
    if (!categoryList) return;

    /* 더미 데이터 — 실제 서비스에서는 API 응답으로 교체 */
    var CATEGORIES = [
      {
        id: 1, name: "의류",
        sub: [
          { id: 11, name: "상의",          count: 120, visible: true  },
          { id: 12, name: "하의",          count: 120, visible: true  },
          { id: 13, name: "홈웨어",        count: 120, visible: true  },
          { id: 14, name: "하위 카테고리 1", count: 0,   visible: false }
        ]
      },
      { id: 2, name: "뷰티",    sub: [] },
      { id: 3, name: "인테리어", sub: [] },
      { id: 4, name: "가전",    sub: [] },
      { id: 5, name: "캠핑",    sub: [] }
    ];

    var selectedCatId    = null;
    var pendingDeleteSubId = null;

    /* SVG 아이콘 상수 */
    var ICON_DRAG = [
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">',
        '<circle cx="5"  cy="4"  r="1.5" fill="currentColor"/>',
        '<circle cx="5"  cy="8"  r="1.5" fill="currentColor"/>',
        '<circle cx="5"  cy="12" r="1.5" fill="currentColor"/>',
        '<circle cx="11" cy="4"  r="1.5" fill="currentColor"/>',
        '<circle cx="11" cy="8"  r="1.5" fill="currentColor"/>',
        '<circle cx="11" cy="12" r="1.5" fill="currentColor"/>',
      "</svg>"
    ].join("");

    var ICON_EDIT = [
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"',
        ' stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">',
        '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>',
        '<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
      "</svg>"
    ].join("");

    var ICON_TRASH = [
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"',
        ' stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">',
        '<polyline points="3 6 5 6 21 6"/>',
        '<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
      "</svg>"
    ].join("");

    /* DOM 참조 */
    var categoryEmpty       = document.getElementById("categoryEmpty");
    var subCategoryContent  = document.getElementById("subCategoryContent");
    var subCategoryTableBody = document.getElementById("subCategoryTableBody");
    var addSubCategoryBtn   = document.getElementById("addSubCategoryBtn");
    var addModal            = document.getElementById("categoryAddModal");
    var deleteModal         = document.getElementById("categoryDeleteModal");
    var newSubCatParent     = document.getElementById("newSubCatParent");

    function getCategoryById(id) {
      return CATEGORIES.find(function (c) { return c.id === id; }) || null;
    }

    function getSubById(subId) {
      var found = null;
      CATEGORIES.forEach(function (cat) {
        cat.sub.forEach(function (s) {
          if (s.id === subId) found = s;
        });
      });
      return found;
    }

    /* ── 좌측 카테고리 리스트 렌더 ── */
    function renderCategoryList() {
      categoryList.innerHTML = CATEGORIES.map(function (cat) {
        var isActive = selectedCatId === cat.id;

        var subListHtml = "";
        if (isActive && cat.sub.length > 0) {
          subListHtml = '<ul class="category-sub-list">' +
            cat.sub.map(function (sub) {
              return [
                '<li class="category-sub-list__item" data-sub-id="' + sub.id + '">',
                  '<span class="category-drag-handle">' + ICON_DRAG + '</span>',
                  '<span class="category-sub-list__name">' + esc(sub.name) + '</span>',
                  '<div class="category-sub-list__actions">',
                    '<button type="button" class="category-icon-btn"',
                      ' aria-label="' + esc(sub.name) + ' 수정"',
                      ' data-action="edit-sub" data-sub-id="' + sub.id + '">',
                      ICON_EDIT,
                    '</button>',
                    '<button type="button" class="category-icon-btn category-icon-btn--danger"',
                      ' aria-label="' + esc(sub.name) + ' 삭제"',
                      ' data-action="delete-sub" data-sub-id="' + sub.id + '">',
                      ICON_TRASH,
                    '</button>',
                  '</div>',
                '</li>'
              ].join("");
            }).join("") +
          '</ul>';
        }

        var addBtnHtml = isActive
          ? [
              '<button type="button" class="category-add-sub-btn"',
                ' data-action="add-sub" data-cat-id="' + cat.id + '"',
                ' aria-label="' + esc(cat.name) + ' 하위 카테고리 추가">',
                esc(cat.name) + " 하위 카테고리 추가",
              '</button>'
            ].join("")
          : "";

        return [
          '<li class="category-list__item' + (isActive ? ' is-active' : '') + '"',
              ' data-cat-id="' + cat.id + '">',
            '<div class="category-list__row" role="button" tabindex="0"',
                ' aria-pressed="' + isActive + '">',
              '<span class="category-drag-handle">' + ICON_DRAG + '</span>',
              '<span class="category-list__name">' + esc(cat.name) + '</span>',
            '</div>',
            subListHtml,
            addBtnHtml,
          '</li>'
        ].join("");
      }).join("");

      /* 클릭 이벤트 */
      categoryList.querySelectorAll(".category-list__row").forEach(function (row) {
        row.addEventListener("click", function () {
          var id = parseInt(row.closest(".category-list__item").dataset.catId, 10);
          selectedCatId = (selectedCatId === id) ? null : id;
          renderCategoryList();
          renderSubPanel();
        });
        row.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            row.click();
          }
        });
      });

      categoryList.querySelectorAll('[data-action="delete-sub"]').forEach(function (btn) {
        btn.addEventListener("click", function (e) {
          e.stopPropagation();
          openDeleteModal(parseInt(btn.dataset.subId, 10));
        });
      });

      categoryList.querySelectorAll('[data-action="add-sub"]').forEach(function (btn) {
        btn.addEventListener("click", function (e) {
          e.stopPropagation();
          openAddModal();
        });
      });
    }

    /* ── 우측 하위 카테고리 패널 렌더 ── */
    function renderSubPanel() {
      if (!selectedCatId) {
        if (categoryEmpty) categoryEmpty.style.display = "flex";
        if (subCategoryContent) subCategoryContent.style.display = "none";
        return;
      }

      var cat = getCategoryById(selectedCatId);
      if (!cat) return;

      if (categoryEmpty) categoryEmpty.style.display = "none";
      if (subCategoryContent) subCategoryContent.style.display = "block";

      if (!subCategoryTableBody) return;

      if (cat.sub.length === 0) {
        subCategoryTableBody.innerHTML =
          '<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--admin-muted); font-size:13px;">' +
          '하위 카테고리가 없습니다.</td></tr>';
        return;
      }

      subCategoryTableBody.innerHTML = cat.sub.map(function (sub, idx) {
        return [
          '<tr>',
            '<td><span class="category-drag-handle">' + ICON_DRAG + '</span></td>',
            '<td>' + (idx + 1) + '</td>',
            '<td>' + esc(sub.name) + '</td>',
            '<td>' + sub.count + '</td>',
            '<td>',
              '<label class="category-toggle" aria-label="' + esc(sub.name) + ' 노출 상태">',
                '<input type="checkbox" ' + (sub.visible ? 'checked' : '') +
                  ' data-sub-id="' + sub.id + '" />',
                '<span class="category-toggle__track"></span>',
              '</label>',
            '</td>',
            '<td>',
              '<div class="category-table-actions">',
                '<button type="button" class="category-icon-btn"',
                  ' aria-label="' + esc(sub.name) + ' 수정">',
                  ICON_EDIT,
                '</button>',
                '<button type="button" class="category-icon-btn category-icon-btn--danger"',
                  ' aria-label="' + esc(sub.name) + ' 삭제"',
                  ' data-action="delete-sub" data-sub-id="' + sub.id + '">',
                  ICON_TRASH,
                '</button>',
              '</div>',
            '</td>',
          '</tr>'
        ].join("");
      }).join("");

      /* 토글 이벤트 */
      subCategoryTableBody.querySelectorAll(".category-toggle input").forEach(function (toggle) {
        toggle.addEventListener("change", function () {
          var sub = getSubById(parseInt(toggle.dataset.subId, 10));
          if (sub) sub.visible = toggle.checked;
        });
      });

      /* 테이블 삭제 버튼 */
      subCategoryTableBody.querySelectorAll('[data-action="delete-sub"]').forEach(function (btn) {
        btn.addEventListener("click", function () {
          openDeleteModal(parseInt(btn.dataset.subId, 10));
        });
      });
    }

    /* ── 모달 제어 ── */
    function openAddModal() {
      if (!addModal) return;
      if (newSubCatParent && selectedCatId) {
        newSubCatParent.value = String(selectedCatId);
      }
      addModal.classList.add("is-open");
      var nameInput = document.getElementById("newSubCatName");
      if (nameInput) setTimeout(function () { nameInput.focus(); }, 50);
    }

    function closeAddModal() {
      if (!addModal) return;
      addModal.classList.remove("is-open");
      var form = document.getElementById("categoryAddForm");
      if (form) form.reset();
    }

    function openDeleteModal(subId) {
      if (!deleteModal) return;
      pendingDeleteSubId = subId;

      var sub = getSubById(subId);
      var subName  = sub ? sub.name  : "";
      var subCount = sub ? sub.count : 0;

      var nameEl  = document.getElementById("deleteSubName");
      var countEl = document.getElementById("deleteSubCount");
      if (nameEl)  nameEl.textContent  = subName;
      if (countEl) countEl.textContent = subCount;

      /* 이동 대상 옵션 채우기 (현재 선택 카테고리의 나머지 sub) */
      var moveTarget = document.getElementById("deleteMoveTarget");
      if (moveTarget) {
        var options = '<option value="">카테고리를 선택하세요</option>';
        CATEGORIES.forEach(function (cat) {
          cat.sub.forEach(function (s) {
            if (s.id !== subId) {
              options += '<option value="' + s.id + '">' +
                esc(cat.name) + " / " + esc(s.name) +
              '</option>';
            }
          });
        });
        moveTarget.innerHTML = options;
      }

      deleteModal.classList.add("is-open");
    }

    function closeDeleteModal() {
      if (!deleteModal) return;
      deleteModal.classList.remove("is-open");
      pendingDeleteSubId = null;
    }

    /* ── 이벤트 바인딩 ── */
    if (addSubCategoryBtn) {
      addSubCategoryBtn.addEventListener("click", openAddModal);
    }

    document.getElementById("addModalOverlay")   &&
      document.getElementById("addModalOverlay").addEventListener("click", closeAddModal);
    document.getElementById("addModalCancelBtn") &&
      document.getElementById("addModalCancelBtn").addEventListener("click", closeAddModal);
    document.getElementById("deleteModalOverlay")   &&
      document.getElementById("deleteModalOverlay").addEventListener("click", closeDeleteModal);
    document.getElementById("deleteModalCancelBtn") &&
      document.getElementById("deleteModalCancelBtn").addEventListener("click", closeDeleteModal);

    var categoryAddForm = document.getElementById("categoryAddForm");
    if (categoryAddForm) {
      categoryAddForm.addEventListener("submit", function (e) {
        e.preventDefault();
        var nameInput = document.getElementById("newSubCatName");
        if (!nameInput || !nameInput.value.trim()) {
          if (nameInput) nameInput.focus();
          return;
        }
        var parentId = parseInt(document.getElementById("newSubCatParent").value, 10);
        var cat = getCategoryById(parentId);
        if (cat) {
          cat.sub.push({ id: Date.now(), name: nameInput.value.trim(), count: 0, visible: true });
          closeAddModal();
          renderCategoryList();
          if (selectedCatId === parentId) renderSubPanel();
        }
      });
    }

    var deleteConfirmBtn = document.getElementById("deleteConfirmBtn");
    if (deleteConfirmBtn) {
      deleteConfirmBtn.addEventListener("click", function () {
        if (pendingDeleteSubId === null) return;
        CATEGORIES.forEach(function (cat) {
          cat.sub = cat.sub.filter(function (s) { return s.id !== pendingDeleteSubId; });
        });
        closeDeleteModal();
        renderCategoryList();
        renderSubPanel();
      });
    }

    /* Escape 키로 모달 닫기 */
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        closeAddModal();
        closeDeleteModal();
      }
    });

    /* XSS 방지 간단 이스케이프 */
    function esc(str) {
      return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }

    /* 초기 렌더 */
    renderCategoryList();
    renderSubPanel();
  }

  /* ══════════════════════════════════════════════
     주문내역 페이지 — order-list.html 전용 함수
     ══════════════════════════════════════════════ */

  var ORDER_STATUSES = ["상품 준비중", "취소 준비중", "취소완료", "배송준비중", "배송중"];

  var STATUS_BADGE_MAP = {
    "상품 준비중": "admin-badge--preparing",
    "취소 준비중": "admin-badge--cancel-pending",
    "취소완료":    "admin-badge--cancel",
    "배송준비중":  "admin-badge--delivery-ready",
    "배송중":      "admin-badge--shipping"
  };

  function getStatusBadgeClass(status) {
    return STATUS_BADGE_MAP[status] || "admin-badge--inactive";
  }

  /**
   * Badge component factory — Figma node 742:5111
   *
   * @param {string}  label       - Display text
   * @param {string}  variant     - One of: preparing | shipping | cancel | pending |
   *                                cancel-pending | delivery-ready | active | inactive |
   *                                notice | important
   * @param {boolean} [dropdown]  - Append chevron (dropdown variant)
   * @returns {string} HTML string
   *
   * Usage:
   *   el.innerHTML = createBadge("배송중", "shipping");
   *   el.innerHTML = createBadge("상품 준비중", "preparing", true);
   */
  function createBadge(label, variant, dropdown) {
    var cls = "admin-badge admin-badge--" + variant;
    if (dropdown) cls += " admin-badge--dropdown";
    return '<span class="' + cls + '">' + label + '</span>';
  }

  /* 전체 선택 체크박스 */
  function initOrderSelection() {
    var selectAll = document.getElementById("orderSelectAll");
    if (!selectAll) return;

    selectAll.addEventListener("change", function () {
      document.querySelectorAll(".order-row-check").forEach(function (cb) {
        cb.checked = selectAll.checked;
      });
    });

    document.addEventListener("change", function (e) {
      if (!e.target.classList.contains("order-row-check")) return;
      var all = document.querySelectorAll(".order-row-check");
      var checked = document.querySelectorAll(".order-row-check:checked");
      if (selectAll) selectAll.checked = (all.length > 0 && all.length === checked.length);
    });
  }

  function getCheckedOrderIds() {
    var ids = [];
    document.querySelectorAll(".order-row-check:checked").forEach(function (cb) {
      ids.push(cb.dataset.orderId);
    });
    return ids;
  }

  /* 선택 주문 일괄 상태 변경 */
  function initOrderStatusChange() {
    var btn = document.getElementById("orderStatusSaveBtn");
    if (!btn) return;
    btn.addEventListener("click", function () {
      var ids = getCheckedOrderIds();
      if (!ids.length) { alert("상태를 변경할 주문을 선택해주세요."); return; }
      var sel = document.getElementById("orderStatusSelect");
      if (!sel || !sel.value) { alert("변경할 상태를 선택해주세요."); return; }
      var newStatus = sel.value;
      /* 선택된 row의 badge 업데이트 */
      ids.forEach(function (id) {
        var curr = document.querySelector('[data-order-current="' + id + '"]');
        if (curr) {
          curr.textContent = newStatus;
          curr.className = "admin-badge t-label-2-md " + getStatusBadgeClass(newStatus);
        }
        /* row dropdown의 current 표시도 갱신 */
        var row = document.querySelector('tr[data-order-id="' + id + '"]');
        if (row) {
          row.querySelectorAll(".admin-order-status__option").forEach(function (o) {
            o.classList.toggle("is-current", o.dataset.status === newStatus);
          });
        }
      });
      alert("선택한 주문의 상태가 변경되었습니다.");
      sel.value = "";
    });
  }

  /* row별 처리 상태 인라인 드롭다운 */
  function initOrderRowStatus() {
    var container = document.getElementById("orderTableBody");
    if (!container) return;

    /* 다른 드롭다운 닫기 */
    function closeAllDropdowns(except) {
      document.querySelectorAll(".admin-order-status__dropdown.is-open").forEach(function (dd) {
        if (dd !== except) dd.classList.remove("is-open");
      });
    }

    container.addEventListener("click", function (e) {
      var toggle = e.target.closest(".admin-order-status__toggle");
      if (toggle) {
        e.stopPropagation();
        var dd = toggle.closest(".admin-order-status").querySelector(".admin-order-status__dropdown");
        if (!dd) return;
        var isOpen = dd.classList.contains("is-open");
        closeAllDropdowns(null);
        if (!isOpen) dd.classList.add("is-open");
        return;
      }

      var opt = e.target.closest(".admin-order-status__option");
      if (opt) {
        e.stopPropagation();
        var orderId = opt.closest("tr").dataset.orderId;
        var newStatus = opt.dataset.status;
        /* toggle 버튼의 badge 업데이트 */
        var curr = document.querySelector('[data-order-current="' + orderId + '"]');
        if (curr) {
          curr.textContent = newStatus;
          curr.className = "admin-badge t-label-2-md " + getStatusBadgeClass(newStatus);
        }
        /* option 현재 표시 갱신 */
        opt.closest(".admin-order-status__dropdown").querySelectorAll(".admin-order-status__option").forEach(function (o) {
          o.classList.toggle("is-current", o.dataset.status === newStatus);
        });
        opt.closest(".admin-order-status__dropdown").classList.remove("is-open");
        alert("주문 상태가 변경되었습니다.");
        return;
      }
    });

    document.addEventListener("click", function () { closeAllDropdowns(null); });
  }

  /* 주문번호 클릭 → 인보이스 생성 */
  function initOrderInvoice() {
    document.addEventListener("click", function (e) {
      if (e.target.classList.contains("admin-order-no")) {
        alert("인보이스가 생성되었습니다.");
      }
    });
  }

  /* 배송지 수정 모달 */
  function initOrderAddressModal() {
    var modal   = document.getElementById("orderAddressModal");
    var overlay = document.getElementById("orderAddressOverlay");
    var cancelBtn = document.getElementById("orderAddressCancelBtn");
    var saveBtn   = document.getElementById("orderAddressSaveBtn");
    if (!modal) return;

    function openModal(data) {
      document.getElementById("oaReceiverName").value    = data.name    || "";
      document.getElementById("oaReceiverPhone").value   = data.phone   || "";
      document.getElementById("oaReceiverAddr").value    = data.addr    || "";
      document.getElementById("oaReceiverAddrDetail").value = data.addrDetail || "";
      modal.classList.add("is-open");
      setTimeout(function () { document.getElementById("oaReceiverName").focus(); }, 50);
    }
    function closeModal() { modal.classList.remove("is-open"); }

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".admin-order-address");
      if (!btn) return;
      openModal({
        name:       btn.dataset.name,
        phone:      btn.dataset.phone,
        addr:       btn.dataset.addr,
        addrDetail: btn.dataset.addrDetail
      });
    });

    if (overlay)   overlay.addEventListener("click", closeModal);
    if (cancelBtn) cancelBtn.addEventListener("click", closeModal);
    if (saveBtn)   saveBtn.addEventListener("click", function () {
      alert("배송지 정보가 수정되었습니다.");
      closeModal();
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && modal.classList.contains("is-open")) closeModal();
    });
  }

  /* 배송자료 다운로드 */
  function initOrderExport() {
    var btn = document.getElementById("orderExportBtn");
    if (!btn) return;
    btn.addEventListener("click", function () {
      var ids = getCheckedOrderIds();
      if (!ids.length) { alert("배송자료를 다운로드할 주문을 선택해주세요."); return; }
      alert("선택한 주문의 배송자료를 다운로드합니다.");
    });
  }

  /* 송장번호 업로드 */
  function initInvoiceUpload() {
    var btn   = document.getElementById("orderInvoiceUploadBtn");
    var input = document.getElementById("orderInvoiceFileInput");
    if (!btn || !input) return;
    btn.addEventListener("click", function () { input.value = ""; input.click(); });
    input.addEventListener("change", function () {
      if (input.files && input.files.length) {
        alert("송장 번호 파일이 선택되었습니다.");
        input.value = "";
      }
    });
  }

  /* 검색 버튼 */
  function initOrderSearch() {
    var btn = document.getElementById("orderSearchBtn");
    if (!btn) return;
    btn.addEventListener("click", function () {
      /* TODO: 실제 API 연동 시 필터 파라미터 전송 */
    });
  }

  /* ══════════════════════════════════════════════
     상품목록 페이지 — product-list.html 전용 함수
     ══════════════════════════════════════════════ */

  /* 모달 열기/닫기 헬퍼 */
  function openProdModal(id)  { var m = document.getElementById(id); if (m) m.classList.add("is-open"); }
  function closeProdModal(id) { var m = document.getElementById(id); if (m) m.classList.remove("is-open"); }

  var currentProdEditId   = null;
  var currentProdDeleteId = null;
  var currentProdCopyId   = null;

  /* 검색 / 필터 */
  function initProductListFilter() {
    var btn = document.getElementById("productFilterSearchBtn");
    if (!btn) return;
    btn.addEventListener("click", function () {
      alert("검색 조건이 적용되었습니다.");
    });
    var inp = document.getElementById("productSearchInput");
    if (inp) inp.addEventListener("keydown", function (e) { if (e.key === "Enter") btn.click(); });
  }

  /* 옵션정보 팝업 */
  function initProductOptionModal() {
    var modal    = document.getElementById("productOptionModal");
    var overlay  = document.getElementById("optionModalOverlay");
    var closeBtn = document.getElementById("optionModalCloseBtn");
    if (!modal) return;

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-option-btn");
      if (!btn) return;
      var tr   = btn.closest("tr");
      var name = tr ? (tr.querySelector(".admin-product-name") || {}).textContent || "" : "";
      var el   = document.getElementById("optionModalProductName");
      if (el) el.textContent = name;
      openProdModal("productOptionModal");
    });

    if (closeBtn) closeBtn.addEventListener("click", function () { closeProdModal("productOptionModal"); });
    if (overlay)  overlay.addEventListener("click",  function () { closeProdModal("productOptionModal"); });
  }

  /* 상품 정보 수정 모달 */
  function initProductEditModal() {
    var modal    = document.getElementById("productEditModal");
    var overlay  = document.getElementById("editModalOverlay");
    var closeBtn = document.getElementById("editModalCloseBtn");
    var saveBtn  = document.getElementById("editModalSaveBtn");
    if (!modal) return;

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-edit-btn");
      if (!btn) return;
      var tr = btn.closest("tr");
      currentProdEditId = tr ? tr.dataset.productId : null;
      openProdModal("productEditModal");
    });

    if (closeBtn) closeBtn.addEventListener("click", function () { closeProdModal("productEditModal"); });
    if (overlay)  overlay.addEventListener("click",  function () { closeProdModal("productEditModal"); });

    if (saveBtn) {
      saveBtn.addEventListener("click", function () {
        var nameField  = document.getElementById("editProductName");
        var priceField = document.getElementById("editProductPrice");
        if (nameField && !nameField.value.trim()) {
          alert("상품명을 입력해주세요.");
          nameField.focus();
          return;
        }
        if (priceField && !priceField.value.trim()) {
          alert("판매가를 입력해주세요.");
          priceField.focus();
          return;
        }
        alert("상품 정보가 수정되었습니다.");
        closeProdModal("productEditModal");
      });
    }
  }

  /* 카테고리 변경 모달 */
  function initProductCategoryModal() {
    var modal    = document.getElementById("productCatModal");
    var overlay  = document.getElementById("catModalOverlay");
    var closeBtn = document.getElementById("catModalCloseBtn");
    var applyBtn = document.getElementById("catModalApplyBtn");
    var openBtn  = document.getElementById("editCatChangeBtn");
    if (!modal) return;

    var CAT_MAP = {
      "의류":    ["상의", "하의", "홈웨어", "잡화"],
      "뷰티":    ["스킨케어", "메이크업", "헤어케어", "바디케어"],
      "홈/리빙": ["가구", "조명", "주방", "욕실"],
      "식품":    ["신선식품", "가공식품", "음료", "건강식품"]
    };
    var selDepth1 = "", selDepth2 = "";

    function renderDepth2(cat) {
      var panel = document.getElementById("productCatDepth2");
      if (!panel) return;
      panel.innerHTML = "";
      (CAT_MAP[cat] || []).forEach(function (sub) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "admin-product-cat-item product-cat-depth2-item";
        b.dataset.cat = sub;
        b.textContent = sub;
        b.addEventListener("click", function () {
          selDepth2 = sub;
          document.querySelectorAll(".product-cat-depth2-item").forEach(function (x) { x.classList.remove("is-selected"); });
          b.classList.add("is-selected");
          var el = document.getElementById("catSelectedLabel");
          if (el) el.textContent = selDepth1 + " > " + selDepth2;
        });
        panel.appendChild(b);
      });
    }

    document.querySelectorAll(".product-cat-depth1-item").forEach(function (btn) {
      btn.addEventListener("click", function () {
        selDepth1 = this.dataset.cat;
        selDepth2 = "";
        document.querySelectorAll(".product-cat-depth1-item").forEach(function (b) { b.classList.remove("is-selected"); });
        this.classList.add("is-selected");
        var el = document.getElementById("catSelectedLabel");
        if (el) el.textContent = selDepth1;
        renderDepth2(selDepth1);
      });
    });

    if (openBtn)  openBtn.addEventListener("click",  function () { openProdModal("productCatModal"); });
    if (closeBtn) closeBtn.addEventListener("click", function () { closeProdModal("productCatModal"); });
    if (overlay)  overlay.addEventListener("click",  function () { closeProdModal("productCatModal"); });

    if (applyBtn) {
      applyBtn.addEventListener("click", function () {
        if (!selDepth1) { alert("카테고리를 선택해주세요."); return; }
        var catText   = selDepth1 + (selDepth2 ? " > " + selDepth2 : "");
        var display   = document.getElementById("editCatDisplay");
        if (display) display.textContent = catText;
        alert("카테고리가 변경되었습니다.");
        closeProdModal("productCatModal");
      });
    }
  }

  /* 상세 페이지 탭 전환 */
  function initProductDetailTabs() {
    if (!document.querySelector(".admin-product-detail-tab")) return;
    document.querySelectorAll(".admin-product-detail-tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        var target = this.dataset.tab;
        document.querySelectorAll(".admin-product-detail-tab").forEach(function (t) { t.classList.remove("is-active"); });
        document.querySelectorAll(".admin-product-tab-panel").forEach(function (p) { p.classList.remove("is-active"); });
        this.classList.add("is-active");
        var panel = document.getElementById(target);
        if (panel) panel.classList.add("is-active");
      });
    });

    /* 이미지 업로드 박스 */
    var uploadBox = document.getElementById("productDetailUploadBox");
    var uploadInput = document.getElementById("productDetailImageInput");
    if (uploadBox && uploadInput) {
      uploadBox.addEventListener("click", function () { uploadInput.value = ""; uploadInput.click(); });
      uploadInput.addEventListener("change", function () {
        var filesEl = document.getElementById("productDetailUploadFiles");
        if (filesEl) filesEl.textContent = uploadInput.files.length ? uploadInput.files.length + "개 파일 선택됨" : "";
      });
    }
  }

  /* 상품 복사 모달 */
  function initProductCopy() {
    var modal     = document.getElementById("productCopyModal");
    var overlay   = document.getElementById("copyModalOverlay");
    var cancelBtn = document.getElementById("copyModalCancelBtn");
    var confirmBtn = document.getElementById("copyModalConfirmBtn");
    if (!modal) return;

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-copy-btn");
      if (!btn) return;
      var tr = btn.closest("tr");
      currentProdCopyId = tr ? tr.dataset.productId : null;
      var name = tr ? (tr.querySelector(".admin-product-name") || {}).textContent || "상품" : "상품";
      var el = document.getElementById("copyModalProductName");
      if (el) el.textContent = name.trim();
      openProdModal("productCopyModal");
    });

    if (cancelBtn)  cancelBtn.addEventListener("click",  function () { closeProdModal("productCopyModal"); });
    if (overlay)    overlay.addEventListener("click",    function () { closeProdModal("productCopyModal"); });
    if (confirmBtn) confirmBtn.addEventListener("click", function () {
      alert("상품이 복사되었습니다.");
      closeProdModal("productCopyModal");
    });
  }

  /* 상품 삭제 모달 */
  function initProductDelete() {
    var modal     = document.getElementById("productDeleteModal");
    var overlay   = document.getElementById("deleteModalOverlay");
    var cancelBtn = document.getElementById("deleteModalCancelBtn");
    var confirmBtn = document.getElementById("deleteModalConfirmBtn");
    if (!modal) return;

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-delete-btn");
      if (!btn) return;
      var tr = btn.closest("tr");
      currentProdDeleteId = tr ? tr.dataset.productId : null;
      openProdModal("productDeleteModal");
    });

    if (cancelBtn)  cancelBtn.addEventListener("click",  function () { closeProdModal("productDeleteModal"); });
    if (overlay)    overlay.addEventListener("click",    function () { closeProdModal("productDeleteModal"); });
    if (confirmBtn) confirmBtn.addEventListener("click", function () {
      if (currentProdDeleteId) {
        var tr = document.querySelector("tr[data-product-id='" + currentProdDeleteId + "']");
        if (tr) tr.remove();
      }
      alert("상품이 삭제되었습니다.");
      closeProdModal("productDeleteModal");
    });
  }

  /* 판매여부 상태 변경 */
  function initProductStatusChange() {
    var STATUS_MSG = {
      "판매마감": "해당 상품의 판매를 마감하시겠습니까?\n판매마감 상태에서는 고객이 상품을 구매할 수 없습니다.",
      "품절":    "해당 상품을 품절 상태로 변경하시겠습니까?\n품절 상태에서는 상품은 노출될 수 있지만 구매는 불가능합니다.",
      "판매중":  "해당 상품을 판매 중 상태로 변경하시겠습니까?"
    };
    var STATUSES  = ["판매중", "판매마감", "품절"];
    var CLS_MAP   = { "판매중": "active", "판매마감": "closed", "품절": "soldout" };

    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-status-btn");
      if (!btn) return;
      var current = btn.dataset.status || "판매중";
      var idx  = STATUSES.indexOf(current);
      var next = STATUSES[(idx + 1) % STATUSES.length];
      var msg  = STATUS_MSG[next] || "상태를 변경하시겠습니까?";
      if (!confirm(msg)) return;
      btn.textContent = next;
      btn.dataset.status = next;
      btn.className = "admin-product-status-btn product-status-btn admin-product-status-btn--" + (CLS_MAP[next] || "active");
      alert("판매 상태가 변경되었습니다.");
    });
  }

  /* 판매링크 복사 */
  function initProductLinkCopy() {
    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".product-link-copy-btn");
      if (!btn) return;
      var link = btn.dataset.link || "https://linkit.kr/product/mock";
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(link).catch(function () {}).finally(function () {
          alert("상품 판매 링크가 복사되었습니다.");
        });
      } else {
        alert("상품 판매 링크가 복사되었습니다.");
      }
    });
  }

  /* ESC로 상품 모달 닫기 */
  function initProductModalEsc() {
    var IDS = ["productOptionModal", "productEditModal", "productCatModal", "productCopyModal", "productDeleteModal"];
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      IDS.forEach(function (id) { closeProdModal(id); });
    });
  }

  /* ── Init ── */
  document.addEventListener("DOMContentLoaded", function () {
    setActiveNav();
    initSidebar();
    initProductSave();
    initProductCreate();
    initCategorySave();
    initSettingsSave();
    initDesignSave();
    initNoticeWrite();
    initSearchBtns();
    initCategoryPage();
    /* 주문내역 */
    initOrderSelection();
    initOrderStatusChange();
    initOrderRowStatus();
    initOrderInvoice();
    initOrderAddressModal();
    initOrderExport();
    initInvoiceUpload();
    initOrderSearch();
    /* 상품목록 */
    initProductListFilter();
    initProductOptionModal();
    initProductEditModal();
    initProductCategoryModal();
    initProductDetailTabs();
    initProductCopy();
    initProductDelete();
    initProductStatusChange();
    initProductLinkCopy();
    initProductModalEsc();
  });
})();
